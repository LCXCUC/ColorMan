
#include <iostream>
#include <fstream>
using namespace std;
#include <stdlib.h>
//#include "stdafx.h"
#include <vector>

#include "opencv2/opencv.hpp"

using namespace std;
using namespace cv;
// -------------------- OpenMesh
#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include <OpenMesh/Core/Mesh/Handles.hh>
typedef OpenMesh::TriMesh_ArrayKernelT<>  MyMesh;
#define N 4096
int FP, asmFP, kmeshFP;
int odl, feature[484], asm_feature[66], kinect_feature[66];
int calcu;
double Ls[N][N], Lt[N][N];

double weightsX[66], weightsY[484], feavalueX[66], feavalueY[3][484], feavalueZ[66], deformX[N], deformY[N], deformZ[N], x[N], y[N], z[N];
int  hds[200000];
int  odls[N];

double LX[N], LY[N], LZ[N], join_x[N], join_y[N], join_z[N], diffx[N], diffy[N], diffz[N];
void Array(int colind);
void Array1(int colind);
double joinx, joiny, joinz, Other;

void Row(int colind);
void Rowt(int colind);

double ai[50];
int ao[50], com1[50], com2[50];
int sum(int lc);
int arri = 0;
int rowi = 0;
int add1;


int main()
{
	
		

		
		MyMesh  mesh;

		if (!OpenMesh::IO::read_mesh(mesh, "64map.obj"))
		{
			return 1;
		}
		odl = 0;
		std::cerr << mesh.n_vertices() << std::endl;//��������
		ofstream outver("outver.txt", ios::app);
		if (outver.is_open())
		{
			outver << mesh.n_vertices();
			outver.close();
		}
		MyMesh::VertexIter  v_it, v_end(mesh.vertices_end());
		MyMesh::HalfedgeIter  e_it;

		MyMesh::VertexHandle fromVertex, toVertex;

		MyMesh::Point point;
		MyMesh::Scalar valence;

		for (v_it = mesh.vertices_begin(); v_it != v_end; ++v_it)
		{
			point = mesh.point(*v_it);
			std::cerr << "Vertex #" << *v_it << ":" << point.data()[0] << point.data()[1] << point.data()[2] << std::endl;

			// circulate around the current vertex   
			valence = 0;
			for (MyMesh::VertexVertexIter vv_it = mesh.vv_iter(*v_it); vv_it.is_valid(); ++vv_it)
			{
				// do something with e.g. mesh.point(*vv_it)
				valence++;
			}

			std::cerr << valence << std::endl;



			ofstream outLin("outdataLin.txt", ios::app);
			if (outLin.is_open())
			{
				outLin << valence << "\n";
				outLin.close();
			}

			odl++;

		}
		int hd = 0;
		for (e_it = mesh.halfedges_begin(); e_it != mesh.halfedges_end(); ++e_it)
		{
			fromVertex = mesh.from_vertex_handle(*e_it);
			toVertex = mesh.to_vertex_handle(*e_it);
			ofstream out("outedge.txt", ios::app);
			if (out.is_open())
			{
				out << fromVertex << "\n";
				out << toVertex << "\n";

				out.close();
			}
			hd += 2;

		}

		ifstream in;
		in.open("outedge.txt", ios::in);
		while (!in.eof())
		{
			for (int hdi = 0; hdi < hd; hdi += 2)
			{
				in >> hds[hdi];

				in >> hds[hdi + 1];

				Ls[hds[hdi]][hds[hdi + 1]] = -1;

			}
		}


		ifstream inL;
		inL.open("outdataLin.txt", ios::in);
		while (!inL.eof())
		{
			for (int odli = 0; odli < N; odli++)
			{
				inL >> odls[odli];
				Ls[odli][odli] = odls[odli];
			}
		}

		





		FP = 484;

		for (int fp = 0; fp<FP; fp++)
		{
			weightsY[fp] = 1;

		}
		/*
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				feature[10 * i + j] = 64 * ( 7 * i) + 7 * j;
			}


		}
		*/
		for (int i = 0; i < 22; i++)
		{
			for (int j = 0; j < 22; j++)
			{
				feature[22 * i + j] = 64 * (3 * i) + 3 * j;

			}


		}
		/*
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				feature[16 * i + j] = 64 * (4 * i) + 4 * j;

			}


		}
		
		for (int j = 0; j < 22; j++)
		{
			weightsY[3*j] = 15;
			weightsY[64*3*21+3*j] = 15;
		}
		for (int i = 0; i < 22; i++)
		{
			weightsY[64 * (3 * i)] = 15;
			weightsY[64 * (3 * i) + 3 * 21] = 15;
		}*/
		/*
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				feature[8 * i + j] = 64 * (9 * i) + 9 * j;
			}


		}*/
		//read feature y value

		
			


		
		



		int zd = 0;
		for (int odli = 0; odli < N; odli++)
		{
			if (odli == feature[zd])
			{

				Lt[odli][odli] = Ls[odli][odli] * Ls[odli][odli] + Ls[odli][odli] + weightsY[zd] * weightsY[zd];
				//Lt1[odli][odli]=Ls[odli][odli]*Ls[odli][odli]+Ls[odli][odli]+weightsY[zd]*weightsY[zd];
				zd++;
			}

			else
			{
				Lt[odli][odli] = Ls[odli][odli] * Ls[odli][odli] + Ls[odli][odli];
				// Lt1[odli][odli]=Ls[odli][odli]*Ls[odli][odli]+Ls[odli][odli];
			}

		}

		/*
		for (int i = 0; i<N; i++)
		{

		Row(i);
		for (int com = 0; com<Ls[i][i] + 1; com++)
		{
		com1[com] = ao[com];
		}

		if (i == N - 1) break;

		int j = i + 1;
		while (j<N)
		{

		Row(j);
		for (int com = 0; com<Ls[j][j] + 1; com++)
		{
		com2[com] = ao[com];
		}

		Other = 0;
		for (int com = 0; com<Ls[i][i] + 1; com++)
		{
		Other += Ls[com1[com]][j] * Ls[com1[com]][i];

		}
		Lt[j][i] = Lt[i][j] = Other;

		ofstream outLt("64outLt.txt", ios::app);
		if (outLt.is_open())
		{
		outLt << Lt[i][j] << "\n";
		outLt.close();
		}

		j++;
		}
		}
		*/

		//next operation
		//next operation 
		// int ii=0;
		
		ifstream inLt;
		inLt.open("64outLt.txt", ios::in);
		while (!inLt.eof())
		{

			//tem[ii];
			//ii++;
			for (int i = 0; i < N; i++)
			{

				for (int j = i + 1; j < N; j++)
				{

					inLt >> Lt[i][j];
					Lt[j][i] = Lt[i][j];



				}

			}

		}
		




		//SuperMatrix A,L, U, Bx,By,Bz;
		double *a, **rhs, **rhsf;
		double s, u, p, e, r, l;
		int *asub, *xa;

		int *perm_r;
		int *perm_c;
		int  info, i, m, n, nnz, permc_spec;
		int nrhs = 64 * 3;
		//superlu_options_t options;
		//SuperLUStat_t stat;

		m = n = N;
		//if ( !(xa = intMalloc(n+1)) ) ABORT("Malloc fails for xa[].");
		xa = (int*)malloc((n + 1) * sizeof(int));
		calcu = 0;
		for (int i = 0; i < N + 1; i++)
		{
			xa[i] = calcu;
			if (i < N) Rowt(i);
		}
		ofstream mapXA("64xa.txt", ios::app);
		if (mapXA.is_open())
		{
			for (int i = 0; i < N + 1; i++)
			{

				mapXA << xa[i] << "\t";

			}

		}
		mapXA.close();
		nnz = calcu;
		ofstream nz("64nnz.txt", ios::app);
		if (nz.is_open())
		{

			nz << nnz;


		}
		nz.close();
		printf("%d", nnz);
		//if ( !(a = doubleMalloc(nnz)) ) ABORT("Malloc fails for a[].");
		a = (double*)malloc(nnz * sizeof(double));
		//if ( !(asub = intMalloc(nnz)) ) ABORT("Malloc fails for asub[].");
		asub = (int*)malloc(nnz * sizeof(int));
		add1 = 0;
		for (int lc = 0; lc < N; lc++)
		{
			int j = 0;
			Array(lc);
			int t = xa[lc + 1];

			for (arri; arri < t; arri++)
			{
				a[arri] = ai[j];
				j++;
			}
		}

		add1 = 0;
		for (int lc = 0; lc < N; lc++)
		{
			int j = 0;
			Rowt(lc);
			int t1 = xa[lc + 1];

			for (rowi; rowi < t1; rowi++)
			{
				asub[rowi] = ao[j];
				j++;
			}
		}
		ofstream mapA("64a.txt", ios::app);
		if (mapA.is_open())
		{
			for (int i = 0; i < nnz; i++)
			{

				mapA << a[i] << "\t";

			}

		}
		mapA.close();


		ofstream mapAsub("64asub.txt", ios::app);
		if (mapAsub.is_open())
		{
			for (int i = 0; i < nnz; i++)
			{

				mapAsub << asub[i] << "\t";

			}

		}
		mapAsub.close();
		free(xa);
		free(a);
		free(asub);
		
		//if (!(rhs = doubleMalloc(m * nrhs))) ABORT("Malloc fails for rhs[].");
		//a = (int**)malloc(sizeof(int*)*m);
		//for (i = 0; i<m; i++)
		//	a[i] = (int*)malloc(sizeof(int)*n);
		rhs = (double**)malloc(nrhs* sizeof(double*));
		for (int i = 0; i<nrhs; i++)
				rhs[i] = (double*)malloc(sizeof(double)*m);
		//if (!(rhsf = doubleMalloc(nrhs * (m + FP)))) ABORT("Malloc fails for rhsf[].");
		rhsf = (double**)malloc(nrhs * sizeof(double*));
		for (int i = 0; i<nrhs; i++)
			rhsf[i] = (double*)malloc(sizeof(double)*(m+FP));

		string outpath = "E:\\BaiduYunDownload\\testA\\hint\\lap\\3_A\\";
		string outpath1 = "E:\\BaiduYunDownload\\testA\\hint\\lap\\3_Bw\\";
		for (int t = 0; t < 64; t++)
		{

			Mat img = imread(outpath + to_string(t) + ".png");
			Mat img1 = imread(outpath1 + to_string(t) + ".png");
		Mat colorim(64, 64, CV_8UC3);



		for (int i = 0; i < 64; i++)
		{
			for (int j = 0; j < 64; j++)
			{
				//join_y[0][64 * i + j] = join_y[1][64 * i + j] = join_y[2][64 * i + j] = img.at<Vec3b>(i, j)[0];
				join_y[64 * i + j] = img.at<Vec3b>(i, j)[0];
			}
			

		}




		ofstream outDiffy("diffy.txt", ios::app);
		if (outDiffy.is_open())
		{
			for (int yi = 0; yi < N; yi++)
			{
				Row(yi);
				joiny = 0;
				for (int k = 0; k <= Ls[yi][yi]; k++)
				{
					if (ao[k] != yi)

						joiny += join_y[ao[k]];
				}

				diffy[yi] = join_y[yi] - joiny / double(Ls[yi][yi]);
				outDiffy << diffy[yi] << "\n";
			}
			outDiffy.close();
		}

		for (int i = 0; i < 22; i++)
		{
			for (int j = 0; j < 22; j++)
			{
				//feature[8 * i + j] = 64 * (3 + 8 * i) + 3 + 8 * j;
				feavalueY[0][22 * i + j] = img1.at<Vec3b>( 3 * i,  3 * j)[0];
				feavalueY[1][22 * i + j] = img1.at<Vec3b>( 3 * i,  3 * j)[1];
				feavalueY[2][22 * i + j] = img1.at<Vec3b>( 3 * i,  3 * j)[2];
			}


		}
		

		
		//memcpy(rhsf[3*t], diffy, sizeof(diffy));
		//memcpy(rhsf[3 * t+1], diffy, sizeof(diffy));
		//memcpy(rhsf[3 * t+2], diffy, sizeof(diffy));

		for (int fp = 0; fp < FP; fp++)
		{
			rhsf[3 * t][N + fp] = feavalueY[0][fp] * weightsY[fp] ;
			rhsf[3 * t + 1][N + fp] = feavalueY[1][fp] * weightsY[fp];
			rhsf[3 * t + 2][N + fp] = feavalueY[2][fp] * weightsY[fp];

		}
		int ti = 0;
		for (int zi = 0; zi < N; zi++)
		{

			Row(zi);
			joinz = 0;
			if (zi == feature[ti])
			{
				ti++;

				for (int k = 0; k <= Ls[zi][zi]; k++)
				{
					if (ao[k] != zi)

						joinz += diffy[ao[k]] * Ls[ao[k]][ao[k]];

				}

				rhs[3 * t][zi] = Ls[zi][zi] * Ls[zi][zi] * diffy[zi] - joinz + rhsf[3 * t][N + ti - 1] * weightsY[ti-1];
				rhs[3 * t + 1][zi] = Ls[zi][zi] * Ls[zi][zi] * diffy[zi] - joinz + rhsf[3 * t + 1][N + ti - 1] * weightsY[ti-1];
				rhs[3 * t + 2][zi] = Ls[zi][zi] * Ls[zi][zi] * diffy[zi] - joinz + rhsf[3 * t + 2][N + ti - 1] * weightsY[ti-1];
			}
			else
			{
				for (int k = 0; k <= Ls[zi][zi]; k++)
				{
					if (ao[k] != zi)

						joinz += diffy[ao[k]] * Ls[ao[k]][ao[k]];

				}

				rhs[3 * t + 2][zi] = rhs[3 * t + 1][zi] = rhs[3 * t][zi] = Ls[zi][zi] * Ls[zi][zi] * diffy[zi] - joinz;
			}
		}
		

		//free(rhs);
		//free(rhsf);

	}
	ofstream maprhs("rhs.txt", ios::app);
	if (maprhs.is_open())
	{
		for (int i = 0; i <  64 * 3; i++)
		{

			for (int j = 0; j < m; j++)
			{
				maprhs << rhs[i][j] << "\t";
			}
			
		 maprhs << "\n";

		}

	}
	maprhs.close();

	for (int i = 0; i<nrhs; i++)
		free(rhs[i]);

	free(rhs);
	for (int i = 0; i<nrhs; i++)
		free(rhsf[i]);

	free(rhsf);
	return 0;
}
int sum(int lc)
{
	add1 += Ls[lc][lc] + 1;
	return add1;
}

void Array(int colind)
{
	int colnum = 0;
	int i = 0;
	while (i<N)
	{
		if (Lt[i][colind] != 0)
		{
			ai[colnum] = Lt[i][colind];
			colnum++;

		}
		i++;
	}
}

void Row(int colind)
{
	int colnum = 0;
	for (int i = 0; i<N; i++)
	{
		if (Ls[i][colind] != 0)
		{
			ao[colnum] = i;
			colnum++;
		}

	}
}

void Rowt(int colind)
{
	int colnum = 0;
	for (int i = 0; i<N; i++)
	{
		if (Lt[i][colind] != 0)
		{
			ao[colnum] = i;
			colnum++;
		}

	}
	calcu += colnum;

}
