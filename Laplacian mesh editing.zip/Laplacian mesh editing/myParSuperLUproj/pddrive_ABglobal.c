/*
Automatic Sketch Colorization Based on Related Subordinate Learning
Hui Ren, Jia Li, Nan Gao
Key Laboratory of Visual Acoustic Technology and Intelligent Control System, Ministry of Culture
Beijing Key Laboratory of Modern Entertainment Technology
Communication University of China, Beijing
Email: renhui@cuc.edu.cn, lcxnn@cuc.edu.cn, sunny-gao@cuc.edu.cn*/


/*! @file 
 * \brief Driver program for pdgssvx_ABglobal example
 *
 * <pre>
 * -- Distributed SuperLU routine (version 1.0) --
 * Lawrence Berkeley National Lab, Univ. of California Berkeley.
 * September 1, 1999
 * </pre>
 */
#include <stdio.h>
#include<math.h>
//#include <stdlib.h>
#include <math.h>
#include "superlu_ddefs.h"
//#include <iostream>
//#include <fstream>
/*! \brief
 *
 * <pre>
 * Purpose
 * =======
 *
 * The driver program pddrive_ABglobal.
 *
 * This example illustrates how to use pdgssvx_ABglobal with the full
 * (default) options to solve a linear system.
 * 
 * Five basic steps are required:
 *   1. Initialize the MPI environment and the SuperLU process grid
 *   2. Set up the input matrix and the right-hand side
 *   3. Set the options argument
 *   4. Call pdgssvx_ABglobal
 *   5. Release the process grid and terminate the MPI environment
 *
 * On an IBM SP, the program may be run by typing
 *    poe pddrive_ABglobal -r <proc rows> -c <proc columns> <input_file> -procs <p>
 * </pre>
 */









int main(int argc, char *argv[])
{
	#define  N  4096
	#define  M  4160
	double Ls[N][N], Lt[N][N];
    superlu_options_t options;
    SuperLUStat_t stat;
    SuperMatrix A;
    ScalePermstruct_t ScalePermstruct;
    LUstruct_t LUstruct;
    gridinfo_t grid;
    double   *berr;
    double   *a, *b, *xtrue;
    int    *asub, *xa;
    int    m, n, nnz;
    int    nprow, npcol;
    int      iam, info, ldb, ldx, nrhs;
    int calcu;
	
    char     trans[1];
    char     **cpp, c;
    FILE *fp;
    extern int cpp_defs();


    nprow = 1;  /* Default process rows.      */
    npcol = 1;  /* Default process columns.   */
    nrhs = 64*3;   /* Number of right-hand side. */

    /* ------------------------------------------------------------
       INITIALIZE MPI ENVIRONMENT. 
       ------------------------------------------------------------*/
    MPI_Init( &argc, &argv );

    /* Parse command line argv[]. */
    for (cpp = argv+1; *cpp; ++cpp) {
	if ( **cpp == '-' ) {
	    c = *(*cpp+1);
	    ++cpp;
	    switch (c) {
	      case 'h':
		  printf("Options:\n");
		  printf("\t-r <int>: process rows    (default %d)\n", nprow);
		  printf("\t-c <int>: process columns (default %d)\n", npcol);
		  exit(0);
		  break;
	      case 'r': nprow = atoi(*cpp);
		        break;
	      case 'c': npcol = atoi(*cpp);
		        break;
	    }
	} 
    }

    /* ------------------------------------------------------------
       INITIALIZE THE SUPERLU PROCESS GRID. 
       ------------------------------------------------------------*/
    superlu_gridinit(MPI_COMM_WORLD, nprow, npcol, &grid);

    /* Bail out if I do not belong in the grid. */
    iam = grid.iam;
    if ( iam >= nprow * npcol )
	goto out;

#if ( VAMPIR>=1 )
    VT_traceoff();
#endif

#if ( DEBUGlevel>=1 )
    CHECK_MALLOC(iam, "Enter main()");
#endif
    
    /* ------------------------------------------------------------
       PROCESS 0 READS THE MATRIX A, AND THEN BROADCASTS IT TO ALL
       THE OTHER PROCESSES.
       ------------------------------------------------------------*/
    //if ( !iam ) {
	/* Print the CPP definitions. */
	cpp_defs();
	
	/* Read the matrix stored on disk in Harwell-Boeing format. */
	//dreadhb_dist(iam, fp, &m, &n, &nnz, &a, &asub, &xa);
	
	

	m = n = N;
	/*
	fp=fopen("4Ls.txt","r");
	int is,js,it,jt;
	for ( is = 0; is < M; is++)
		{
			for( js=0;js<N;js++)
			{
				fscanf(fp,"%lf",&Ls[is][js]);
				//if(Ls[is][js]!=0) printf("\t%lf\n", Ls[is][js]);
			}
			
		}
	fclose(fp);
	fp=fopen("4Lt.txt","r");
	for ( it = 0; it < N; it++)
		{
			for( jt=0;jt<N;jt++)
			{
				fscanf(fp,"％lf",&Lt[it][jt]);
				//if(Lt[it][jt]!=0) printf("\t%lf\n", Lt[it][jt]);
			}
			
		}
	fclose(fp);
	*/
/*
	ifstream inLs;
	inLs.open("90Ls.dat", ios::in);
	while (!inLs.eof())
	{
		for (int i = 0; i < M; i++)
		{
			for(int j=0;j<N;j++)
			{
				inLs >>Ls[i][j]>>"\t" ;
				//Ls[i][j] = odls[odli];
			}
			inLs>>"\n";
		}
	}

	ifstream inLt;
	inLt.open("90Lt.dat", ios::in);
	while (!inLt.eof())
	{
		for (int i = 0; i < N; i++)
		{
			for(int j=0;j<N;j++)
			{
				inLt >>Lt[i][j]>>"\t" ;
				//Ls[i][j] = odls[odli];
			}
			inLt>>"\n";
		}
	}
*/
if ( !(xa = intMalloc_dist(n+1)) ) ABORT("Malloc fails for xa[].");
fp=fopen("64xa.txt","r");
	int ixa;
	for ( ixa = 0; ixa < n+1; ixa++)
		{
			
				fscanf(fp,"%d",&xa[ixa]);
				
			
			
		}
	fclose(fp);
 
	fp=fopen("64nnz.txt","r");
	
			
	fscanf(fp,"%d",&nnz);
	fclose(fp);

printf("\tDimension\t%dx%d\t # nonzeros %d\n", m, n, nnz);
if ( !(a = doubleMalloc_dist(nnz)) ) ABORT("Malloc fails for a[].");
fp=fopen("64a.txt","r");
	int ia;
	for ( ia = 0; ia < nnz; ia++)
		{
			
				fscanf(fp,"%lf",&a[ia]);
			
		}
	fclose(fp);
if ( !(asub = intMalloc_dist(nnz)) ) ABORT("Malloc fails for asub[].");
fp=fopen("64asub.txt","r");
	int iasub;
	for ( iasub = 0; iasub < nnz; iasub++)
		{
			
				fscanf(fp,"%d",&asub[iasub]);
			
		}
	fclose(fp);




	
	printf("\tProcess grid\t%d X %d\n", grid.nprow, grid.npcol);
	/* Broadcast matrix A to the other PEs. */
	MPI_Bcast( &m,   1,   mpi_int_t,  0, grid.comm );
	MPI_Bcast( &n,   1,   mpi_int_t,  0, grid.comm );
	MPI_Bcast( &nnz, 1,   mpi_int_t,  0, grid.comm );
	MPI_Bcast( a,    nnz, MPI_DOUBLE, 0, grid.comm );
	MPI_Bcast( asub, nnz, mpi_int_t,  0, grid.comm );
	MPI_Bcast( xa,   n+1, mpi_int_t,  0, grid.comm );
    //} else {
	/* Receive matrix A from PE 0. */
	//MPI_Bcast( &m,   1,   mpi_int_t,  0, grid.comm );
	//MPI_Bcast( &n,   1,   mpi_int_t,  0, grid.comm );
	//MPI_Bcast( &nnz, 1,   mpi_int_t,  0, grid.comm );

	/* Allocate storage for compressed column representation. */
	//dallocateA_dist(n, nnz, &a, &asub, &xa);

	//MPI_Bcast( a,    nnz, MPI_DOUBLE, 0, grid.comm );
	//MPI_Bcast( asub, nnz, mpi_int_t,  0, grid.comm );
	//MPI_Bcast( xa,   n+1, mpi_int_t,  0, grid.comm );
    //}
	
    


    /* Create compressed column matrix for A. */
    dCreate_CompCol_Matrix_dist(&A, m, n, nnz, a, asub, xa,
				SLU_NC, SLU_D, SLU_GE);

    /* Generate the exact solution and compute the right-hand side. */
    if (!(b=doubleMalloc_dist(m*nrhs))) ABORT("Malloc fails for b[]");
    //if (!(xtrue=doubleMalloc_dist(n*nrhs))) ABORT("Malloc fails for xtrue[]");
    *trans = 'N';
    ldx = n;
    ldb = m;
    //dGenXtrue_dist(n, nrhs, xtrue, ldx);
    //dFillRHS_dist(trans, nrhs, xtrue, ldx, &A, b, ldb);
	fp=fopen("rhs.txt","r");
	int irhs,jrhs;
	//for(jrhs=0;jrhs<nrhs;jrhs++)
	//{
		for ( irhs = 0; irhs < m*nrhs; irhs++)
			{
				
					fscanf(fp,"%lf",&b[irhs]);
				
			}
	//}
	fclose(fp);

    if ( !(berr = doubleMalloc_dist(nrhs)) )
	ABORT("Malloc fails for berr[].");

    /* ------------------------------------------------------------
       NOW WE SOLVE THE LINEAR SYSTEM.
       ------------------------------------------------------------*/

    /* Set the default input options:
        options.Fact = DOFACT;
        options.Equil = YES;
        options.ColPerm = METIS_AT_PLUS_A;
        options.RowPerm = LargeDiag;
        options.ReplaceTinyPivot = YES;
        options.Trans = NOTRANS;
        options.IterRefine = DOUBLE;
        options.SolveInitialized = NO;
        options.RefineInitialized = NO;
        options.PrintStat = YES;
     */
    set_default_options_dist(&options);

    /* Initialize ScalePermstruct and LUstruct. */
    ScalePermstructInit(m, n, &ScalePermstruct);
    LUstructInit(m, n, &LUstruct);

    /* Initialize the statistics variables. */
    PStatInit(&stat);

    /* Call the linear equation solver. */
    pdgssvx_ABglobal(&options, &A, &ScalePermstruct, b, ldb, nrhs, &grid,
		     &LUstruct, berr, &stat, &info);

	fp=fopen("192b.txt","w");
	int nb,nn;
	//for(nn=0;nn<nrhs;nn++)
	//{
		for(nb=0;nb<m*nrhs;nb++)
		{
			if(b[nb]<0) b[nb]=0;
			if(b[nb]>255) b[nb]=255;
 			fprintf(fp,"%lf\t",round(b[nb]));
			if(nb>0&&nb%m==0) fprintf(fp,"\n");
		}
		
	//}
	fclose(fp);
    /* Check the accuracy of the solution. */
    //if ( !iam ) {
	//dinf_norm_error_dist(n, nrhs, b, ldb, xtrue, ldx, &grid);
    //}
    //PStatPrint(&options, &stat, &grid);        /* Print the statistics. */

    /* ------------------------------------------------------------
       DEALLOCATE STORAGE.
       ------------------------------------------------------------*/
    PStatFree(&stat);
    Destroy_CompCol_Matrix_dist(&A);
    Destroy_LU(n, &grid, &LUstruct);
    ScalePermstructFree(&ScalePermstruct);
    LUstructFree(&LUstruct);
    SUPERLU_FREE(b);
    //SUPERLU_FREE(xtrue);
    SUPERLU_FREE(berr);

    /* ------------------------------------------------------------
       RELEASE THE SUPERLU PROCESS GRID.
       ------------------------------------------------------------*/
out:
    superlu_gridexit(&grid);

    /* ------------------------------------------------------------
       TERMINATES THE MPI EXECUTION ENVIRONMENT.
       ------------------------------------------------------------*/
    MPI_Finalize();

#if ( DEBUGlevel>=1 )
    CHECK_MALLOC(iam, "Exit main()");
#endif

}


int cpp_defs()
{
    printf(".. CPP definitions:\n");
#if ( PRNTlevel>=1 )
    printf("\tPRNTlevel = %d\n", PRNTlevel);
#endif
#if ( DEBUGlevel>=1 )
    printf("\tDEBUGlevel = %d\n", DEBUGlevel);
#endif
#if ( PROFlevel>=1 )
    printf("\tPROFlevel = %d\n", PROFlevel);
#endif
#if ( StaticPivot>=1 )
    printf("\tStaticPivot = %d\n", StaticPivot);
#endif
    printf("....\n");
    return 0;
}
