#include <opencv2/core/core.hpp>    
#include "opencv2/opencv.hpp"
#include <opencv2/highgui/highgui.hpp>    
#include <iostream>  
#include <opencv2/imgproc/imgproc.hpp>  
#include <vector>  
using namespace std;
using namespace cv;;
double L[192][4096];
void main()
{       //���÷ָ��ͼ��洢·��
	//string outpath = "E:\\BaiduYunDownload\\testA\\hint\\lap\\1_A\\";
	//Mat img = imread("E:\\BaiduYunDownload\\testA\\hint\\seg\\seg\\1_A.png"); //��ͼ�������Ŀ�����ʹ��imread������ȡ
	Mat img(512, 512, CV_8UC3);
	int t = 0;
	FILE *fp;
	//Vector<Mat> ceil_img;  //������ceil_img�洢��ͼ��
	//Vector<int> name;     //������name�洢��ͼ������֣���0��m*n-1
	//for (t; t < m*n; t++)
	//	name.push_back(t);
	//Mat image_cut, roi_img, tim_img;

	string outpath = "E:\\BaiduYunDownload\\testA\\hint\\lap\\t3\\";
	//string outpath1 = "E:\\BaiduYunDownload\\testA\\hint\\lap\\1_Bw\\";
	fp = fopen("192b.txt", "r");
	for (int i = 0; i < 192; i++)
	{
		for (int j = 0; j < 4096; j++)
		{
			//join_y[0][64 * i + j] = join_y[1][64 * i + j] = join_y[2][64 * i + j] = img.at<Vec3b>(i, j)[0];
			//join_y[64 * i + j] = img.at<Vec3b>(i, j)[0];
			fscanf(fp, "%lf", &L[i][j]);
		}
	}
	fclose(fp);
	for (int t = 0; t < 64; t++)
	{

		//Mat img = imread(outpath + to_string(t) + ".png");
		//Mat img1 = imread(outpath1 + to_string(t) + ".png");
		Mat colorim(64, 64, CV_8UC3);
		//for (int i = 3*t; i < 3*t+2; i++)
		//{
		//	for (int j = 0; j < 4096; j++)
		//	{
		//		fscanf(fp, "%lf", &L[i%3][j]);
		//	}
			for (int i = 0; i < 64; i++)
					{
						for (int j = 0; j < 64; j++)
						{
							colorim.at<Vec3b>(i, j)[0] = int(L[3*t][64 * i + j]);
							colorim.at<Vec3b>(i, j)[1] = int(L[3*t+1][64 * i + j]);
							colorim.at<Vec3b>(i, j)[2] = int(L[3*t+2][64 * i + j]);
				
						}
					}
			

		
		
		imwrite(outpath + to_string(t) + ".png", colorim);

	}
	
	
	for (int i = 0; i <8; i++)
	{
		for (int j = 0; j< 8; j++)
		{
			Mat image_cut = imread(outpath + to_string(8*i+j) + ".png");
			for (int si = 64 * i; si < 64 * i + 64; si++)
			{
				for (int sj = 64 * j; sj < 64 * j + 64; sj++)
				{
					img.at<Vec3b>(si, sj) = image_cut.at<Vec3b>(si % 64, sj % 64);
				}
			}
			//Rect rect(i * 64, j * 64, 64, 64);
		    //Mat(img, rect)=image_cut;
			//roi_img = image_cut.clone();
			//ceil_img.push_back(roi_img);
		}
	}
	imwrite(outpath +  "overall.png", img);
}
